import 'dotenv/config';

export const BACKEND_HOST = process.env.HOST || '0.0.0.0';
export const BACKEND_PORT = parseInt(process.env.PORT || '5050', 10);
export const DATABASE_URL = process.env.DATABASE_URL || '';
export const REDIS_HOST = process.env.REDIS_HOST || 'localhost';
export const REDIS_PORT = parseInt(process.env.REDIS_PORT || '6379', 10);
export const ALLOWED_ORIGINS = process.env.ALLOWED_ORIGINS
  ? process.env.ALLOWED_ORIGINS.split(',').map(origin => origin.trim())
  : ['http://localhost:3000', 'http://127.0.0.1:3000'];
export const STRIPE_SECRET_KEY = process.env.STRIPE_SECRET_KEY || '';
export const PAYPAL_CLIENT_ID = process.env.PAYPAL_CLIENT_ID || '';
export const PAYPAL_SECRET = process.env.PAYPAL_SECRET || '';
export const PAYPAL_MODE = process.env.PAYPAL_MODE || 'sandbox';
export const PAYMENT_PROVIDER = process.env.PAYMENT_PROVIDER || 'stripe';
