import { DATABASE_URL } from './env';

let prisma: any = null;

if (DATABASE_URL) {
  try {
    // Attempt to require Prisma if available in this environment. If not, fall back to a safe noop object.
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const pkg = require('@prisma/client');
    const PrismaClient = pkg && (pkg.PrismaClient || pkg.default?.PrismaClient || pkg.default);
    if (PrismaClient) {
      prisma = new PrismaClient({ datasources: { db: { url: DATABASE_URL } } });
      prisma.$connect().catch(() => {
        // Connection errors are handled by the application startup logic.
      });
    }
  } catch (err) {
    prisma = {
      $disconnect: async () => {},
      $connect: async () => {},
    } as any;
  }
} else {
  console.warn('[DB Config] DATABASE_URL is not configured. Falling back to noop Prisma client.');
  prisma = {
    $disconnect: async () => {},
    $connect: async () => {},
  } as any;
}

export default prisma;
