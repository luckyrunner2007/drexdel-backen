import { PaymentRequestPayload, PaymentResponseResult } from '../../@types/drexdel_app_types';

export class CardGateway {
  private readonly secretKey: string;
  private stripeClient: any;

  constructor(secretKey: string) {
    this.secretKey = secretKey;
    if (secretKey) {
      try {
        // eslint-disable-next-line @typescript-eslint/no-var-requires
        const Stripe = require('stripe');
        this.stripeClient = new Stripe(secretKey, { apiVersion: '2024-11-01' });
      } catch {
        this.stripeClient = null;
      }
    }
  }

  public async processCardPayment(payload: PaymentRequestPayload): Promise<PaymentResponseResult> {
    if (!payload.customerEmail) {
      return {
        success: false,
        transactionId: payload.transactionId,
        gatewayReference: 'FAILED_CARD_MISSING_EMAIL',
        error: 'Credit card payments require a customer email for receipts.',
        escrowStatus: 'failed'
      };
    }

    if (!this.stripeClient) {
      return {
        success: false,
        transactionId: payload.transactionId,
        gatewayReference: 'FAILED_CARD_GATEWAY_UNINITIALIZED',
        error: 'Stripe credentials are not available in the backend environment.',
        escrowStatus: 'failed'
      };
    }

    try {
      // In production, create PaymentIntent with Stripe and confirm payment before returning success.
      const paymentIntent = await this.stripeClient.paymentIntents.create({
        amount: Math.round((payload.amount || 0) * 100),
        currency: payload.currency?.toLowerCase() || 'usd',
        receipt_email: payload.customerEmail,
        metadata: {
          transactionId: payload.transactionId,
          eventId: payload.eventId,
          userId: payload.userId || 'guest',
        },
      });

      return {
        success: true,
        transactionId: payload.transactionId,
        gatewayReference: paymentIntent.id,
        escrowStatus: 'held_in_escrow'
      };
    } catch (error: any) {
      return {
        success: false,
        transactionId: payload.transactionId,
        gatewayReference: 'FAILED_STRIPE_PAYMENT',
        error: error?.message || 'Stripe payment authorization failed.',
        escrowStatus: 'failed'
      };
    }
  }
}
