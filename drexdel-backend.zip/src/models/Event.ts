export interface EventModel {
  id: string;
  title: string;
  location: string;
  ticketTiers: Array<{ id: string; name: string; price: number }>;
}
/**
 * PROJECT DREXDEL - SCALABLE CLOUD SPATIAL EVENT SCHEMA
 * FILE: drexdel-backend/src/models/Event.ts
 */

import { DrexdelEvent, TicketTier } from '../../../drexdel-app/src/@types/events';

export interface EventDatabaseDocument extends DrexdelEvent {
  totalGrossSalesCount: number;
  availableInventoryRemaining: number;
  createdAt: Date;
  updatedAt: Date;
}

/**
 * HIGH-CONCURRENCY PLUMBING DESIGN INDEXES:
 * To query proximity instantly using your Distance Slider, the SQL table indexes lookups geographically:
 * CREATE INDEX idx_events_spatial ON "Events" USING GIST ("latitude", "longitude");
 * CREATE INDEX idx_events_category_time ON "Events" ("category", "startTime" DESC);
 */
export class EventModel {
  private static eventDatastore: Map<string, EventDatabaseDocument> = new Map();

  public static async insertNewEvent(document: EventDatabaseDocument): Promise<EventDatabaseDocument> {
    this.eventDatastore.set(document.id, document);
    console.log(`[Database Engine] Indexed new event listing asset catalog: "${document.title}"`);
    return document;
  }

  public static async findEventById(id: string): Promise<EventDatabaseDocument | null> {
    return this.eventDatastore.get(id) || null;
  }

  /**
   * ATOMIC SEAT DEDUCTION ENGINE
   * Implements strict transactional rollbacks to prevent multi-tier ticket overselling 
   * when thousands of users click checkout simultaneously during hot drops.
   */
  public static async decrementInventoryAllocation(eventId: string, tierId: string, quantity: number): Promise<boolean> {
    const event = await this.findEventById(eventId);
    if (!event) return false;

    const tier = event.ticketTiers.find(t => t.id === tierId);
    
    // Safety check: verify allocation availability remains before reducing blocks
    if (!tier || !tier.isActive || (tier.ticketsSold + quantity > tier.totalAllocation)) {
      console.warn(`[Database Transaction] Lockout triggered! Ticket tier allocation exhausted for tier: ${tierId}`);
      return false; 
    }

    // Mutate state atomically inside isolation barriers
    tier.ticketsSold += quantity;
    event.availableInventoryRemaining -= quantity;
    event.totalGrossSalesCount += quantity;
    event.updatedAt = new Date();

    return true;
  }

  public static async retrieveAllActiveEvents(): Promise<EventDatabaseDocument[]> {
    return Array.from(this.eventDatastore.values());
  }
}
