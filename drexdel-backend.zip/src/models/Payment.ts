import prisma from '../config/db';

export enum PaymentStatus {
  Pending = 'pending',
  Completed = 'completed',
  Failed = 'failed',
}

export interface PaymentRecord {
  id?: string;
  transactionId: string;
  eventId: string;
  userId: string;
  amount: number;
  currency: string;
  paymentMethod: string;
  customerPhone?: string | null;
  customerEmail?: string | null;
  status: PaymentStatus;
  gatewayReference?: string | null;
  errorMessage?: string | null;
  createdAt: string;
  updatedAt: string;
}

const hasPrismaPayments = (prisma as any)?.payment && typeof (prisma as any).payment.create === 'function';

export class PaymentModel {
  private static datastore = new Map<string, PaymentRecord>();

  public static async create(record: PaymentRecord): Promise<PaymentRecord> {
    if (hasPrismaPayments) {
      return (prisma as any).payment.create({
        data: {
          ...record,
          createdAt: new Date(record.createdAt),
          updatedAt: new Date(record.updatedAt),
        },
      });
    }

    this.datastore.set(record.transactionId, record);
    return record;
  }

  public static async updateStatus(
    transactionId: string,
    status: PaymentStatus,
    gatewayReference?: string | null,
    errorMessage?: string | null
  ): Promise<PaymentRecord | null> {
    if (hasPrismaPayments) {
      return (prisma as any).payment.update({
        where: { transactionId },
        data: {
          status,
          gatewayReference,
          errorMessage,
          updatedAt: new Date(),
        },
      });
    }

    const existing = this.datastore.get(transactionId);
    if (!existing) return null;

    const updated = {
      ...existing,
      status,
      gatewayReference: gatewayReference ?? existing.gatewayReference,
      errorMessage: errorMessage ?? existing.errorMessage,
      updatedAt: new Date().toISOString(),
    };
    this.datastore.set(transactionId, updated);
    return updated;
  }

  public static async findByTransactionId(transactionId: string): Promise<PaymentRecord | null> {
    if (hasPrismaPayments) {
      return (prisma as any).payment.findUnique({ where: { transactionId } });
    }

    return this.datastore.get(transactionId) || null;
  }
}
