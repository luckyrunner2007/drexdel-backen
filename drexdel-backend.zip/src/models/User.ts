export interface UserModel {
  id: string;
  email: string;
  name: string;
  role: 'casual' | 'organiser' | 'staff';
}
/**
 * PROJECT DREXDEL - SECURE CLOUD DATABASE USER SCHEMA
 * FILE: drexdel-backend/src/models/User.ts
 */

import { UserProfile, UserRole } from '../../../drexdel-app/src/@types/events';

// Blueprint layout enforcing optimized indexing on identification layers for O(1) query lookups
export interface UserDatabaseDocument extends Omit<UserProfile, 'createdAt'> {
  passwordHash: string; // Securely hashed password text string using bcrypt-pbkdf rails
  escrowWalletBalance: number; // For promoters tracking side incomes from house parties
  devicePushToken?: string;    // Registration ID for pushing real-time ticket alerts
  isAccountLocked: boolean;
  createdAt: Date;
  updatedAt: Date;
}

/**
 * PRODUCTION DATABASING IMPLEMENTATION NOTE:
 * At a 500,000 active user scale, these structures translate into SQL tables with explicit indexes:
 * CREATE UNIQUE INDEX idx_users_email ON "Users" ("email");
 * CREATE INDEX idx_users_role ON "Users" ("role");
 */
export class UserModel {
  // Local simulated cloud PostgreSQL indexing data engine map
  private static userDatastore: Map<string, UserDatabaseDocument> = new Map();

  public static async create(document: UserDatabaseDocument): Promise<UserDatabaseDocument> {
    this.userDatastore.set(document.id, document);
    console.log(`[Database Engine] Securely committed user account table record: ${document.email}`);
    return document;
  }

  public static async findById(id: string): Promise<UserDatabaseDocument | null> {
    return this.userDatastore.get(id) || null;
  }

  public static async findByEmailOrPhone(identity: string): Promise<UserDatabaseDocument | null> {
    const cleanIdentity = identity.trim().toLowerCase();
    for (const doc of this.userDatastore.values()) {
      if (doc.email === cleanIdentity || doc.phoneNumber === identity) {
        return doc;
      }
    }
    return null;
  }

  /**
   * Pushes checked-in events into the user's permanent History Vault tracking arrays
   */
  public static async pushAttendedEventId(userId: string, eventId: string): Promise<boolean> {
    const record = await this.findById(userId);
    if (!record) return false;

    if (!record.attendedEventIds.includes(eventId)) {
      record.attendedEventIds.push(eventId);
      record.updatedAt = new Date();
    }
    return true;
  }
}
