import prisma from '../config/db';
import { EncryptedTicket } from '../@types/drexdel_app_types';

const hasPrismaTickets = (prisma as any)?.ticket && typeof (prisma as any).ticket.create === 'function';

export class TicketModel {
  private static datastore = new Map<string, EncryptedTicket>();

  public static async create(ticket: EncryptedTicket): Promise<EncryptedTicket> {
    if (hasPrismaTickets) {
      return (prisma as any).ticket.create({
        data: {
          id: ticket.id,
          transactionId: ticket.id,
          eventId: ticket.eventId,
          userId: ticket.userId,
          tierId: ticket.tierId,
          cryptographicToken: ticket.cryptographicToken,
          qrCodeString: ticket.qrCodeString,
          status: ticket.status,
          createdAt: new Date(ticket.purchaseTimestamp),
          updatedAt: new Date(ticket.purchaseTimestamp),
        },
      });
    }

    this.datastore.set(ticket.id, ticket);
    return ticket;
  }

  public static async findById(ticketId: string): Promise<EncryptedTicket | null> {
    if (hasPrismaTickets) {
      return (prisma as any).ticket.findUnique({ where: { id: ticketId } });
    }
    return this.datastore.get(ticketId) || null;
  }
}
