import { Request, Response } from 'express';
import prisma from '../config/db'; // Pulling in our new Postgres connector engine

// 1. DYNAMIC FETCH: Pull all real events out of our PostgreSQL database
export const getAllEvents = async (req: Request, res: Response) => {
  try {
    const events = await prisma.event.findMany({
      orderBy: { date: 'asc' } // Keep upcoming house parties sorted nicely by date
    });
    return res.status(200).json(events);
  } catch (error) {
    return res.status(500).json({ error: 'Failed to stream data packets from database.' });
  }
};

// 2. DYNAMIC CREATION: Permanently save a brand new event straight to the database table
export const createEvent = async (req: Request, res: Response) => {
  try {
    const { title, description, date, location, ticketPrice } = req.body;
    
    const newEvent = await prisma.event.create({
      data: {
        title,
        description,
        date: new Date(date), // Formats text date string into a clean database DateTime stamp
        location,
        ticketPrice: parseFloat(ticketPrice) || 0.0
      }
    });
    
    return res.status(201).json(newEvent);
  } catch (error) {
    return res.status(500).json({ error: 'Failed to write new transaction record to database.' });
  }
};

