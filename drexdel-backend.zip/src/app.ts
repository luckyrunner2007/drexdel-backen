/**
 * PROJECT DREXDEL - ARCHITECTURAL PORT LOCK ENGINE (MASTER CORE)
 * FILE: drexdel-backend/src/app.ts
 */

import express from 'express';
import http from 'http';
import cluster from 'cluster';
import os from 'os';
import { ALLOWED_ORIGINS } from './config/env';
import { paymentController } from './controllers/paymentController';
import { getAllEvents, createEvent } from './controllers/eventController';

if (cluster.isPrimary) {
  const totalCpuCoresCount = Math.min(os.cpus().length, 4);
  console.log(`[Cloud Master] Activating Drexdel Core. Spawning ${totalCpuCoresCount} cluster paths...`);

  for (let i = 0; i < totalCpuCoresCount; i++) {
    cluster.fork();
  }

  cluster.on('exit', (worker) => {
    console.warn(`[Cloud Master] Thread process ${worker.process.pid} closed. Auto-reviving context node...`);
    cluster.fork();
  });
} else {
  const app = express();
  const server = http.createServer(app);

  app.use(express.json());

  app.use((req, res, next) => {
    const origin = String(req.headers.origin || '');
    if (ALLOWED_ORIGINS.includes(origin)) {
      res.setHeader('Access-Control-Allow-Origin', origin);
    }
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    next();
  });

  app.options('*', (req, res) => {
    res.sendStatus(204);
  });

  app.get('/', (req, res) => {
    console.log(`[Worker Core ${process.pid}] Transmitting health-check asset packet`);
    res.status(200).json({ service: 'drexdel-backend', status: 'running', pid: process.pid });
  });

  app.get('/v1/events', getAllEvents);
  app.post('/v1/events', createEvent);
  app.post('/v1/payments/checkout', paymentController.handleCheckout.bind(paymentController));
  app.post('/v1/payments/telecom-webhook', paymentController.handleTelecomCallback.bind(paymentController));

  app.get('/health', (req, res) => {
    res.status(200).json({ status: 'ok', pid: process.pid, uptime: process.uptime() });
  });

  //  FIX: Bound seamlessly to AWS dynamic environment parameters and dropped explicit host filters
  const TARGET_PORT = Number(process.env.PORT) || 5050;

  server.listen(TARGET_PORT, () => {
    console.log(`[Worker Thread] System process ${process.pid} successfully locked onto deployment port: ${TARGET_PORT} 🚀`);
  });
}
